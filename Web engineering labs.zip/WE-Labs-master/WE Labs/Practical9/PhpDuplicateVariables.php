<?php
$array = array("a" => "moon", "star", "b" => "moon", "star", "sky");
$result = array_unique($array);
print_r($result);
?>

